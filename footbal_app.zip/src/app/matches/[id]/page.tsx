import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function MatchDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  
  const match = await prisma.match.findUnique({
    where: { id },
    include: {
      tournament: true,
      events: {
        include: { player: true },
        orderBy: { minute: 'desc' }
      },
      callUps: {
        include: { player: true }
      }
    }
  });

  if (!match) return <div className="page-container"><p>Partita non trovata</p></div>;

  const homeGoals = match.location === 'HOME' ? match.events.filter(e => e.type === 'GOAL').length : 0; // Simplified scoring
  const awayGoals = match.location === 'AWAY' ? match.events.filter(e => e.type === 'GOAL').length : 0;

  return (
    <main className="page-container">
      <header className="page-header" style={{ background: 'var(--primary)', color: 'white' }}>
        <Link href="/matches" style={{ color: 'white', textDecoration: 'none' }}>← Indietro</Link>
        <h1 style={{ color: 'white' }}>Live Match</h1>
        <div style={{ width: '60px' }}></div>
      </header>

      <section className="match-scoreboard" style={{ padding: '2rem', textAlign: 'center', background: 'var(--surface)', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '2rem' }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{match.location === 'HOME' ? 'Noi' : match.opponent}</h2>
            <span style={{ fontSize: '3rem', fontWeight: '900', color: 'var(--primary)' }}>{match.location === 'HOME' ? homeGoals : '?'}</span>
          </div>
          <span style={{ fontSize: '1.5rem', color: 'var(--text-muted)' }}>-</span>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{match.location === 'AWAY' ? 'Noi' : match.opponent}</h2>
            <span style={{ fontSize: '3rem', fontWeight: '900', color: 'var(--primary)' }}>{match.location === 'AWAY' ? awayGoals : '?'}</span>
          </div>
        </div>
        <p style={{ marginTop: '1rem', color: 'var(--text-muted)' }}>{new Date(match.date).toLocaleDateString("it-IT")}</p>
      </section>

      <section style={{ padding: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1.5rem' }}>
          <Link href={`/matches/${match.id}/callups`} className="primary-action-button" style={{ background: 'var(--surface)', color: 'var(--primary)', border: '1px solid var(--primary)', textDecoration: 'none' }}>
            📋 Gestisci Convocazioni
          </Link>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
          <button className="primary-action-button" style={{ padding: '1rem', fontSize: '1.2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <span style={{ fontSize: '2rem' }}>⚽</span>
            Gol
          </button>
          <button className="primary-action-button" style={{ background: 'var(--warning)', padding: '1rem', fontSize: '1.2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <span style={{ fontSize: '2rem' }}>🔄</span>
            Cambio
          </button>
        </div>

        <h3 style={{ marginBottom: '1rem', fontWeight: 'bold' }}>Cronaca (Eventi)</h3>
        {match.events.length === 0 ? (
          <p className="text-muted" style={{ textAlign: 'center' }}>Nessun evento registrato.</p>
        ) : (
          <ul className="item-list">
            {match.events.map(event => (
              <li key={event.id} className="list-item" style={{ padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <div style={{ fontWeight: 'bold', color: 'var(--primary)', width: '40px' }}>{event.minute}'</div>
                <div>
                  {event.type === 'GOAL' && <span>⚽ Gol di <strong>{event.player.lastName}</strong></span>}
                  {event.type === 'SUBSTITUTION' && <span>🔄 Entra <strong>{event.player.lastName}</strong></span>}
                  {event.type === 'YELLOW_CARD' && <span>🟨 Giallo a <strong>{event.player.lastName}</strong></span>}
                  {event.type === 'RED_CARD' && <span>🟥 Rosso a <strong>{event.player.lastName}</strong></span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
