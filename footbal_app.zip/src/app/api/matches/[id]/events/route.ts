import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { minute, type, playerId, goalType, assistId, subOutId } = body;

    if (minute === undefined || !type || !playerId) {
      return NextResponse.json({ error: "Minute, type, and playerId are required" }, { status: 400 });
    }

    const event = await prisma.matchEvent.create({
      data: {
        matchId: id,
        minute: parseInt(minute, 10),
        type,
        playerId,
        goalType: goalType || null,
        assistId: assistId || null,
        subOutId: subOutId || null,
      },
    });

    return NextResponse.json(event, { status: 201 });
  } catch (error) {
    console.error("Error creating match event:", error);
    return NextResponse.json({ error: "Failed to create match event" }, { status: 500 });
  }
}
