import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as { _prismaInstance?: PrismaClient };

// Inizializzazione Lazy (Pigra) tramite Proxy:
// Il `PrismaClient` non viene instanziato quando il file viene importato, 
// ma solo alla prima query effettiva. Questo risolve in modo definitivo 
// i problemi di PrismaClientInitializationError causati dai worker 
// di Next.js durante la fase di build.
export const prisma = new Proxy({} as PrismaClient, {
  get(target, prop) {
    if (!globalForPrisma._prismaInstance) {
      globalForPrisma._prismaInstance = new PrismaClient();
    }
    const client = globalForPrisma._prismaInstance as any;
    return client[prop];
  }
});

if (process.env.NODE_ENV !== "production") globalForPrisma._prismaInstance = prisma;
