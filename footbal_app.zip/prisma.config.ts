import { defineConfig } from "prisma/config";

export default defineConfig({
  schema: "prisma/schema.prisma",
  datasource: {
    // Fallback obbligatorio per evitare errori di inizializzazione durante la build
    url: process.env.DATABASE_URL || "file:./dev.db",
  },
});
